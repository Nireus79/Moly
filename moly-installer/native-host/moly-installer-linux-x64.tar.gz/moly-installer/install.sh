#!/bin/bash
set -e

echo "Installing Moly Native Host..."
sudo cp moly-native-host /usr/local/bin/moly-native-host
sudo chmod +x /usr/local/bin/moly-native-host

mkdir -p ~/.config/google-chrome/NativeMessagingHosts
mkdir -p ~/.config/chromium/NativeMessagingHosts

echo "Native host installed to /usr/local/bin/moly-native-host"
echo ""
echo "Next: Set MOLY_EXTENSION_ID in your environment and configure native messaging:"
echo "  export MOLY_EXTENSION_ID=your-extension-id"
